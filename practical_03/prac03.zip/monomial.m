function u = monomial(x,n)

u = x.^n;

end