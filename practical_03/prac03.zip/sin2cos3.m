function u = sin2cos3(x)

u = sin(x).^2.*cos(x).^3;

end